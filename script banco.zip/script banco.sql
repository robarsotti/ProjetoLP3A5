create database BDControleFinancas;
use BDControleFinancas;


create table categoria(
id_categoria int primary key auto_increment,
ds_categoria varchar(40)
);


create table tipoMovimentacao(
id_tipo_movimentacao int primary key auto_increment,
ds_tipo_mov varchar(50)
);

create table movimentacao(
id_movimentacao int primary key auto_increment,
vlr_movimentacao double not null,
dt_movimentacao date,
dt_cadastro_mov TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
id_tipo_movimentacao int,
id_categoria int,

CONSTRAINT FK_MOV_TIPO FOREIGN KEY (id_tipo_movimentacao) REFERENCES tipoMovimentacao(id_tipo_movimentacao),
CONSTRAINT FK_CATEGORIA FOREIGN KEY (id_categoria) REFERENCES categoria(id_categoria)
);

